"""OpenGL.EGL the portable interface to GL environments"""
from OpenGL.raw.GLES3._types import *
from OpenGL.GLES2.VERSION.GLES2_2_0 import *
from OpenGL.GLES3.VERSION.GLES3_3_0 import *
from OpenGL.GLES3.VERSION.GLES3_3_1 import *
