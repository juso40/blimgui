from OpenGL.platform import PLATFORM as _p
_error_checker = None
